import java.util.HashMap;
import java.util.List;


public class Sym {
    private String type;
    private boolean iFxn;
    private boolean iStrct;
    private HashMap<String, Sym> strctMembers;
    private List<String> fxnArgs;
    
    public Sym(String type) {
        this.type = type;
        iFxn = false;
        iStrct = false;
        strctMembers = null;
    }
    
    public void setStrct(boolean bool){
        iStrct = bool;
    }
    
    public boolean getStrct(){
        return iStrct;
    }
    
    public void setFxn(boolean bool){
        iFxn = bool;
    }
    
    public void setFxnArgs(List<String> fxnList){
        fxnArgs = fxnList;
    }
    
    public List<String> getFxnArgs(){
        return fxnArgs;
    }
    
    
    public boolean getFxn(){
        return iFxn;
    }
    
    public HashMap<String,Sym> getStrctMembers(){
        return strctMembers;
    }
    
    public void mapStrct(HashMap<String, Sym> hash){
        strctMembers = hash;
    }

    
    public void outputStrctMembers(){
        System.out.println();
        System.out.print("Struct Members:");
        System.out.println();
        System.out.print(strctMembers.toString());
        System.out.println();
    }
    
    public String getType() {
        return type;
    }
    
    public String toString() {
        return type;
    }
}
