import java.util.*;

public class iSym {
    
    private String type;
    private String name;
    
    public iSym(String type, String name) {
        this.type = type;
        this.name = name;
    }
    
    public iSym(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public String getName() {
        return name;
    }
    
    public String toString() {
        return type;
    }
}

class FxnSym extends iSym {
    
    private String retType;
    private int numFormals;
    private LinkedList formalsTypes;
    
    public FxnSym(String type, String name, int numFormals) {
        super(name, null);
        this.numFormals = numFormals;
        this.retType = type;
    }
    
    public void setFormals(LinkedList list) {
        this.formalsTypes = list;
    }
    
    public String getRetType() {
        return this.retType;
    }
    
    public int getNumFormals() {
        return this.numFormals;
    }
    
    public LinkedList getFormalsTypes() {
        return this.formalsTypes;
    }
    
    public String toString() {
        String ret = "";
        for(int i = 0; i < formalsTypes.size(); i++) {
            ret += formalsTypes.get(i);
            ret += ",";
        }
        return ret + "->" + this.retType;
    }
    
}

class StructSym extends iSym {
    
    private String type;
    private List<String> members;
    
    public StructSym(List<String> members, String type) {
        super(type);
        this.members = members;
    }
    
    public List<String> getMembers() {
        return members;
    }
    
}

